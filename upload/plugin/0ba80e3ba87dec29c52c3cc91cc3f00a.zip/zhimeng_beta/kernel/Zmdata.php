<?php
require_once ENTITYPATH . '/Entity.php';

class Zmdata extends Entity {

    var $id;

    var $title;

    var $litpic;

    var $keywords;

    var $description;

    var $body;

    public function validate() {
        
    }
}
