	$(function(){
		
		$('#register').on('shown.zui.modal', function () {
			
			$('#checkcode').html('<div class="col-xs-8"><input class="form-control" id="ckcode" name="ckcode" placeholder="输入验证码" value="" type="text" nullmsg="验证码不能为空！"></div><div class="col-xs-4"><img id="mpdc4_ckcode" height="31" src="./public/img/verify.php"></div>');
			});
		
		
		var loginform=$("#loginform").Validform({
			btnSubmit:"#losubmit", 			
			tiptype:function(msg, o, cssctl){
				if (o.type != 2) {
					
					//状态为2表示通过验证，成功就不提示						
					//页面上不存在提示信息的标签时，自动创建		
					if(o.obj.hasClass('authcode')){
						var $alam=o.obj.parent().next().next();								
						$alam.html('<span class="Validform_checktip"></span>');
						
						var objtip = o.obj.parent().parent().parent().find(".Validform_checktip");								
						cssctl(objtip,o.type);						
						objtip.text(msg);
					}
					else{
						var $alam=o.obj.parent().next();								
						$alam.html('<span class="Validform_checktip"></span>');
						var objtip = o.obj.parent().parent().find(".Validform_checktip");								
						cssctl(objtip,o.type);						
						objtip.text(msg);
					}
				}
				else if (o.type == 2){
					 if(o.obj.hasClass('authcode')){
							var $alam=o.obj.parent().next().next();								
							$alam.html('<span class="Validform_checktip Validform_right"></span>');
							
					}
					else{
						var $alam=o.obj.parent().next();								
						$alam.html('<span class="Validform_checktip Validform_right"></span>');								
					}							
						
				}
			}, 
			
			ajaxPost:true,
			url:'/home.php?mod=login&method=dologin',
			beforeSubmit:function(curform){
				$.ajax({
					'url':'/home.php?mod=login&method=gettoken',
					'success':function(data){
						if(data.status){
							$('#lotoken').remove();
							
							curform.append('<input type="hidden" id="lotoken" name="lotoken" value="'+data.data+'">');
							
						}
					}
				});
				//密码进行md5加密
				
				curform.find(':input[type=password]').each(function(){
					
					$(this).val($.md5($(this).val()));
					
				});
				
				//在验证成功后，表单提交前执行的函数，curform参数是当前表单对象。
				//这里明确return false的话表单将不会提交;	
			},
			callback:function(data){//清除提交状态
				//registerform.setStatus("normal");
				//$("#registerform").find('.Validform_checktip').each(function(){
					$('.Validform_checktip').removeClass('Validform_loading');
					$('.Validform_checktip').html('');
				//});
				if(data.status){//注册成功
					console.log("成功");
				}else{
					
					console.log(data.msg);
					$('#mpdc4_ckcode').attr('src','../public/img/verify.php?' + Math.random());	
					$('#tpassword').val('');
				}
				
				
			},
			
				
		});
		
	});