function Register() {
this.init=function(){
	var self = this;
	var count=60;
	$(function(){
		$('body').on('click','#mpdc3_ckcode',function(){
			self.changecode();
			});	
				
		var registerform=$("#registerform").Validform({
			btnSubmit:"#submit", 			
			tiptype:function(msg, o, cssctl){
				if (o.type != 2) {
					
					//状态为2表示通过验证，成功就不提示						
					//页面上不存在提示信息的标签时，自动创建		
					if(o.obj.hasClass('authcode')){
						var $alam=o.obj.parent().next().next();								
						$alam.html('<span class="Validform_checktip"></span>');
						
						var objtip = o.obj.parent().parent().parent().find(".Validform_checktip");								
						cssctl(objtip,o.type);						
						objtip.text(msg);
					}
					else{
						var $alam=o.obj.parent().next();								
						$alam.html('<span class="Validform_checktip"></span>');
						var objtip = o.obj.parent().parent().find(".Validform_checktip");								
						cssctl(objtip,o.type);						
						objtip.text(msg);
					}
				}
				else if (o.type == 2){
					 if(o.obj.hasClass('authcode')){
							var $alam=o.obj.parent().next().next();								
							$alam.html('<span class="Validform_checktip Validform_right"></span>');
							
					}
					else{
						var $alam=o.obj.parent().next();								
						$alam.html('<span class="Validform_checktip Validform_right"></span>');								
					}							
						
				}
			}, 
			
			ajaxPost:true,
			url:'/home.php?mod=register&method=register',
			beforeSubmit:function(curform){
				//密码进行md5加密
				curform.find(':input[type=password]').each(function(){
					$(this).val($.md5($(this).val()));
				});
				
				//在验证成功后，表单提交前执行的函数，curform参数是当前表单对象。
				//这里明确return false的话表单将不会提交;	
			},
			callback:function(data){//清除提交状态
				//registerform.setStatus("normal");
				//$("#registerform").find('.Validform_checktip').each(function(){
					$('.Validform_checktip').removeClass('Validform_loading');
					$('.Validform_checktip').html('');
				//});
				if(data.status){//注册成功
					console.log("成功");
				}else{
					self.changecode();
					console.log(data.msg);
					$('#password').val('');
					
				}
				
				
			},
			
				
		});
		$('body').on('click','#getcode',function(){
			var mobile=$('#mobile').val();
			var token=$('#token').val();
			if(count<60){
				return false;
			}
			$.ajax({
				'url':'/home.php?mod=register&method=sendcode',
				'type':'POST',
				'dataType':'json',
				'data': {mobile:mobile, token:token},
				'success':function(data){
					if(data.stute){
						$("#getcode").attr('disabled', true);
						$("#getcode").removeClass('btn-success');
						$("#getcode").addClass('btn-default');
						var int=setInterval(function(){														
							count=count-1;							
							if(count>0){
							$('#getcode').html(count+'秒后重新获取');
							//console.log(count);
							}else{
								window.clearInterval(int);
								count=60;
								$('#getcode').html('获取验证码');
								$("#getcode").removeClass('btn-default');
								$("#getcode").addClass('btn-success');
							}						
						},1000);
					}
				}
				
				
			});
		});
		
	});
}	
this.changecode=function(){
	
		$('#mpdc3_ckcode').attr('src','../public/img/verify.php?' + Math.random());	
		
}
}