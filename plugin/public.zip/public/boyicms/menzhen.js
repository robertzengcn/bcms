/*   function getdoctors(dep1,dep2,date,time){
	   alert(dep1);
    	var dep =$(this).attr('value1');
    	// var dep = $('#dep').val() == '' ? dep1 : $('#dep').val();
    	var date = $('#date').val() == '' ? date : $('#date').val();
    	var time = $('#time').val() == '' ? time : $('#time').val();
    	console.log(this);
    	$.ajax({
    		type:'GET',
			url:"/controller?controller=Reservation&method=getdoctors&dep="+dep+"&date="+date+"&time="+time,
			dataType: 'json',
			success: function(result){
				console.log(result.data);
			}
    	})
    	
    }*/


